export const brand_logo = require('./brand-logo.png').default;
export const upload_img = require('./img-scan.jpg').default;
export const table_user = require('./user.jpg').default;
export const livestream_img = require('./img-upload.jpg').default;
export const bin_icon = require('./dlt.svg').default;
export const edit_icon = require('./edit.svg').default;