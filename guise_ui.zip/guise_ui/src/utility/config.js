// eslint-disable-next-line
export default {
    apiUrl : 'https://fast-cliffs-16495.herokuapp.com'
 };